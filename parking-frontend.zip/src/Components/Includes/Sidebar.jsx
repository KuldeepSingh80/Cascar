import React, { useEffect, useState } from "react";
import "Assets/StyleCss/sidebar.css";
import C_logo from "Assets/Images/c.svg";
import { FaCaravan, FaMap, FaUserCog } from "react-icons/fa";
import { IoMapSharp } from "react-icons/io5";
import { FiLogOut } from "react-icons/fi";
import { RiParkingFill } from "react-icons/ri";
import logo from "Assets/Images/carparking.png";
import avatar from "Assets/Images/avatar1.png";
import { MdWork } from "react-icons/md";
import { useLocation } from "react-router-dom";
import toggleleft from "Assets/Images/toggleleft.svg";
import { Link } from "react-router-dom";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { IconButton, Tooltip } from "@mui/material";
import Loader from "Loader";
import { toast } from "react-toastify";
import LogoutConfirmation from "Assets/Dialog box/LogoutConfirmation";
export default function SideBar({ handleSidebarToggle, sidebarStatus }) {
  const navigate = useNavigate();
  const location = useLocation();
  const [username, setUsername] = useState("");
  const [useremail, setUseremail] = useState("");
  const [actives, setactive] = React.useState("dashboard");
  const [issuperadmin, setissuperadmin] = React.useState(false);
  function handlelogout() {
    localStorage.clear();

    navigate("/");
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("token");
    localStorage.removeItem("user");
  }
  function userID() {
    axios
      .get(`${process.env.REACT_APP_API_URL}/api/me/`, {
        headers: {
          Authorization: `Token ${localStorage.getItem("token")}`,
        },
      })
      .then((res) => {
        setUsername(res.data.username);
        setUseremail(res.data.email);

        setissuperadmin(res?.data?.is_superuser);

        localStorage.setItem("isLoggedIn", true);
      })
      .catch((err) => {
        handlelogout();
        toast.error("Session Expired, Please login again");
      });
  }
  const pathname = location.pathname.split("/")[1];
  useEffect(() => {
    // if (!window.google || !window.google.translate) {
    //   const script = document.createElement('script');
    //   script.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
    //   script.async = true;
    //   document.body.appendChild(script);
    // }
    userID();
    setactive(pathname);
  }, [pathname]);

  const [logoutConfirmationState, setLogoutConfirmationState] = useState(false);
  const handleToCloseLogoutConfirmation = () => {
    setLogoutConfirmationState(false);
  };
  const handleToOpenLogoutConfirmation = () => {
    setLogoutConfirmationState(true);
  };

  return (
    <>
      <div className="sidebar_wrrpr">
        <div className="sidebar_dv">
          <div className="sidebar_head">
            <div className={`sidebar_collapsed_logo ${sidebarStatus}`}>
              <img src={C_logo} alt="logo" />{" "}
            </div>{" "}
            <div className="sidebar_logo">
              <img src={logo} className="sidebar_logo" alt="logo" />{" "}
            </div>
          </div>
          <div className="sidebar_toggle">
            <button
              className="sidebar_toggle_btn"
              onClick={() => {
                handleSidebarToggle();
              }}
            >
              <div className="closemenu">
                <img src={toggleleft} alt={"logo"} />
              </div>
            </button>
          </div>
          <div className="sidebar_body">
            <ul className="navigation">
              <li
                className={`${
                  pathname === "dashboard" ? "activeitem" : "noactive"
                }`}
              >
                <Link to="/dashboard">
                  <FaMap className="menuicons" />
                  <span className="sidebar_menu_name">Map</span>
                </Link>
              </li>
              <li
                className={`${
                  pathname === "vehicles" ? "activeitem" : "noactive"
                }`}

              >
                <Link to="/vehicles">
                  <FaCaravan className="menuicons" />
                  <span className="sidebar_menu_name">Vehicles</span>
                </Link>
              </li>
            
                <li
                  className={`${
                    pathname === "users" ? "activeitem" : "noactive"
                  }`}
                >
                  <Link to="/users">
                    <FaUserCog className="menuicons" />
                    <span className="sidebar_menu_name">User Management</span>
                  </Link>
                </li>


              <li
                className={`${
                  pathname === "workload" ? "activeitem" : "noactive"
                }`}
              >
                <Link to="/workload">
                  <MdWork className="menuicons" />
                  <span className="sidebar_menu_name">Work Load</span>
                </Link>
              </li>
              <li>
              {/* <button onClick={() => changeLanguage('es')}>Spanish</button>
        <button onClick={() => changeLanguage('fr')}>French</button> */}
        {/* Add more language buttons as needed */}
    
              </li>
            </ul>
          </div>

          <div className={`sidebar_foot ${sidebarStatus}`}>
            <div className=" sidebar_toggle2"></div>

            <ul>
              <li className="sidebar_foot_li sidebar_foot_avatar_li sb-avatar">
                <img src={avatar} alt="avatar" />
              </li>
              <li className="sidebar_foot_li sb-detail">
                <p className="textfootername">{username} </p>
                <p className="textfooteremail">{useremail}</p>
              </li>
              <li
                className={`sidebar_foot_li_second menuicons log-btn sb-logout `}
              >
                <Tooltip title="Logout" arrow>
                  <IconButton
                    className={`${sidebarStatus}`}
                    onClick={() => {
                      handleToOpenLogoutConfirmation();
                    }}
                  >
                    <FiLogOut className="logout" />
                  </IconButton>
                </Tooltip>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <LogoutConfirmation
        open={logoutConfirmationState}
        onClose={handleToCloseLogoutConfirmation}
        title="Are you sure you want to logout ?"
        onConfirm={() => {
          handlelogout();
        }}
      />
    </>
  );
}
