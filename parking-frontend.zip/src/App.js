import React, { useEffect, useCallback, useRef } from "react";
import MyRoutes from "./MyRoutes";
import { ToastContainer } from "react-toastify";
import dutch from './Assets/Images/dutch.svg'
import english from './Assets/Images/english.svg'
import { Height } from "@mui/icons-material";
const App = () => {
  const googleTranslateElementRef = useRef(null);
  const googleTranslateElementInit = useCallback(() => {
   
    new window.google.translate.TranslateElement(
      {
        pageLanguage: "en",
        includedLanguages: "en,nl,it",
        excludedClasses: "notranslate",
        autoDisplay: false,
      },
      googleTranslateElementRef.current
    );
  }, []);

  const scriptRef = useRef(null);

  useEffect(() => {
    function loadGoogleTranslateScript() {
      if (!window.google || !window.google.translate) {
        const newScript = document.createElement("script");
        newScript.src = "//translate.google.com/translate_a/element.js";
        newScript.id = "googleTranslateScript";
        newScript.async = true;

        newScript.onload = () => {
          window.googleTranslateElementInit = googleTranslateElementInit;
          googleTranslateElementInit(); // Initialize the translator
        };

        newScript.onerror = (error) => {
        
        };

        document.body.appendChild(newScript);
        scriptRef.current = newScript;
      } else {
        // If the script is already loaded, directly initialize the translator
        googleTranslateElementInit();
      }
    }

    loadGoogleTranslateScript();

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        // Reload or reinitialize the script when the tab becomes visible
        loadGoogleTranslateScript();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      // Clean up any other event listeners or resources if needed
    };
  }, [googleTranslateElementInit]);
  const handleToChangeLanguage = (languageCode) => {
    const selectElement = document.querySelector('.goog-te-combo');
  
    // Trigger a change event on the select element
    if (selectElement) {
      selectElement.value = languageCode;
      const event = new Event('change', { bubbles: true });
      selectElement.dispatchEvent(event);
    }

  }
  return (
    <>
      <div ref={googleTranslateElementRef} style={{ textAlign: 'end' }}></div>
      <div class="language-changer notranslate">
  {/* <span>Change Language:</span> */}
  <button class="lang-button" onClick={() => { handleToChangeLanguage('nl') }}><img src={dutch} style={{width:'17px',Height:'17px'}}/>NL</button> 
  <button class="lang-button" onClick={() => { handleToChangeLanguage('en') }}><img src={english} style={{width:'17px',Height:'17px'}}/>EN</button> 
 </div>

      <ToastContainer />
      <MyRoutes />
    </>
  );
};

export default App;
