import { configureStore } from "@reduxjs/toolkit";
import thunk from "redux-thunk";
import userSlice from "redux/slices/UserSlice";
import VehicleSlice from "redux/slices/VehicleSlice";
import workloadReducer from "redux/slices/WorkloadSlice";
import ParkingReducer from "redux/slices/ParkingSlice";
import modalReducer from "redux/slices/modalSlice"
const store = configureStore({
  reducer: {
    vehicle: VehicleSlice,
    user: userSlice,
    workload: workloadReducer,
    parking: ParkingReducer,
    modal: modalReducer,
  },
  middleware: [thunk],
});

export default store;
