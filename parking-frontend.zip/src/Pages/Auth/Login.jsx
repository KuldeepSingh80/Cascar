import React, { useState } from "react";
import logo from "../../Assets/Images/cascarparking.svg";
import "../../Assets/StyleCss/styles.css";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { TextValidator, ValidatorForm } from "react-material-ui-form-validator";

export default function Login() {
  const [rememberme, setrememberme] = useState(false);
  const [loginobj, setloginobj] = useState({
    email: "",
    password: "",
  });
  const navigate = useNavigate();

  function handleCheck() {
    setrememberme(!rememberme);
  }

  function onchange(e) {
    setloginobj({ ...loginobj, [e.target.name]: e.target.value });
  }

  function handlelogin(e) {
    e.preventDefault();

    axios
      .post(`${process.env.REACT_APP_API_URL}/api/login/`, loginobj)
      .then((res) => {
        if (res.status === 200) {
          localStorage.setItem("token", res.data.token);
          localStorage.setItem("isLoggedIn", true);
          localStorage.setItem("user", JSON.stringify(res.data.user));
          navigate("/dashboard");
        }
      })
      .catch((err) => {
        localStorage.setItem("isLoggedIn", false);
        toast.error("Invalid email or password.", {
          position: toast.POSITION.BOTTOM_RIGHT,
        });
      });
  }

  return (
    <>
      <div className="mainbody">
        <div className="login-outerdiv">
          <div className="loginsection">
            <ValidatorForm
              className="loginform"
              onSubmit={(e) => handlelogin(e)}
            >
              <div className="logintitle">
                <img className="logo" src={logo} alt="img" />
                <div className="logotitle">
                  Let’s login to your Cascar Parking Map Account
                </div>
              </div>
              <div className="loginformcontrol">
                <label className="loginlabel">Email</label>
                <TextValidator
                  variant="outlined"
                  validators={["required", "isEmail"]}
                  errorMessages={["Email is required ", "Email is not valid"]}
                  className="logininput"
                  name="email"
                  value={loginobj.email}
                  onChange={onchange}
                  type="text"
                />
              </div>
              <div className="loginformcontrol">
                <label className="loginlabel">Password</label>
                <TextValidator
                  variant="outlined"
                  validators={["required"]}
                  value={loginobj.password}
                  errorMessages={["Password is required"]}
                  className="logininput"
                  name="password"
                  onChange={onchange}
                  type="password"
                />
              </div>

              <div className="LoginButton">
                <button type="submit" className="loginbuttoncontrol">
                  Login
                </button>
              </div>
            </ValidatorForm>
          </div>
        </div>
      </div>

      <div className="loginfooter">
        <span>Copyright by Cascar Parking Map 2023</span>
      </div>
    </>
  );
}
