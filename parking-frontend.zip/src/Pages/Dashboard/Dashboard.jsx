import React, { useState, useRef } from "react";
import washingicon from "Assets/Images/washingicon.svg";
import polishingicon from "Assets/Images/polishingicon.svg";
import pickbyicon from "Assets/Images/pickbyicon.svg";
import { FaCircle } from "react-icons/fa";
import ParkingInfo from "./ParkingInfo";
import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import { getAllVehicles } from "redux/slices/VehicleSlice";
import { fetchWorks, getAllIconMap, getAllParkingMap } from "redux/slices/ParkingSlice";
import Repairingicon from "Assets/Images/damageicon.svg";

import Panzoomcls from "./Panzoom";
import { toast } from "react-toastify";
import Loader from "Loader";
const Dashboard = () => {
  const dispatch = useDispatch();
  const [loader, setLoader] = useState(true);
  const parkingData = useSelector((state) => state.parking.getAllParkingMap);
  const parkIconsData = useSelector((state) => state.parking.getAllIconMap)
  const { loading } = useSelector((state) => state.parking)
  const open = useSelector((state) => state.modal.open);
  const data = useSelector((state) => state.modal.data);
  const [autoCenterState, setAutoCenterState] = useState(false)

  useEffect(() => {
    if(parkingData.length > 0 ){
      setLoader(false);
    } 
  }, [parkingData])


  const iconMapping = {
    Repairing: Repairingicon,
    Polishing: polishingicon,
    Washing: washingicon,
    Pickup: pickbyicon,
    Arriving: ""
    // Add more mappings as needed
  };

  useEffect(() => {
    dispatch(getAllIconMap())
    dispatch(getAllParkingMap());
    dispatch(getAllVehicles());
    dispatch(fetchWorks());
  }, [dispatch]);



  return (
    <div className="parkingmap">
      <div className="sectiontitle">
        <div className="title">
          <label className="titletag">Map</label>
        </div>
        <div className="parking-header">
          <ul className="header-icons">
            {
              parkIconsData.map((iconsdata, index) => {
                return <li className="header-list">
                  <img width="18px" height="18px" style={{
                    width: "18px",
                    height: "18px",
                  }} src={iconMapping[iconsdata?.name]}
                    alt={iconsdata?.name} />
                  <span>{iconsdata?.name}</span>
                </li>
              })
            }
            {/* <li className="header-list">
              <img width="18px" height="18px" style={{
                width: "18px",
                height: "18px",
              }} src={Repairingicon} alt="polishingicon" />
              <span>Repairing</span>
            </li>
            <li className="header-list">
              <img style={{
                width: "20px",
                height: "20px",
              }} width="20px" height="20px" src={polishingicon} alt="polishingicon" />
              <span>Polishing</span>
            </li>
            <li className="header-list">
              <img style={{
                width: "20px",
                height: "20px",
              }} width="20px" height="20px" src={washingicon} alt="polishingicon" />
              <span>Washing</span>
            </li>
            <li className="header-list">
              <img style={{
                width: "20px",
                height: "20px",
              }} width="20px" height="20px" src={pickbyicon} alt="polishingicon" />
              <span>Pick by Owner</span>
            </li> */}

          </ul>
        </div>
      </div>
      {/* <div
        className="parking-map-wrapper "
        style={{
          position: "relative",
        }}
      > */}
      {!loader ? (
        <Panzoomcls open={open} data={data} parkingData={parkingData} />
      ) : (
        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            height: '100%',
          }}
        >
          <Loader />
        </div>
      )}
      {/* </div> */}
      <div className="parkingmap-footer">
        <ul>
          <li>
            <span>
              <FaCircle style={{ color: "#56C72F" }} />
              Monday
            </span>
          </li>
          <li>
            <span>
              <FaCircle style={{ color: "#3483DF" }} />
              Tuesday
            </span>
          </li>
          <li>
            <span>
              <FaCircle style={{ color: "#FBBC5E" }} />
              Wednesday
            </span>
          </li>
          <li>
            <span>
              <FaCircle style={{ color: "#01CFC5" }} />
              Thursday
            </span>
          </li>
          <li>
            <span>
              <FaCircle style={{ color: "#FF649C" }} />
              Friday
            </span>
          </li>
          <li>
            <span>
              <FaCircle style={{ color: "#1C3C60" }} />
              Saturday
            </span>
          </li>
          <li>
            <span>
              <FaCircle style={{ color: "#8F2FAD" }} />
              Next Week
            </span>
          </li>
          <li>
            <span>
              <FaCircle style={{ color: "#FF251E" }} />
              Overdue
            </span>
          </li>
        </ul>
      </div>
      <div className="parkingmap-sidepopper">
        <ParkingInfo data={data} open={open} />
      </div>
    </div>
  );
};

export default React.memo(Dashboard);
