import React, { useEffect, useState, useRef, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import PanZoomCol from './PanZoomCol';
import Loader from 'Loader';
import { getAllParkingMap } from 'redux/slices/ParkingSlice';
import { Ensure10Records } from 'utils/Ensure10Records';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutline';
import panzoom from 'panzoom';
import { Button, IconButton } from '@mui/material';

const Panzoomcls = ({ open, setopen, data, setdata,parkingData }) => {
 
  const [panScale, setPanScale] = useState(-1); // Set an initial negative value
  const [panPosition, setPanPosition] = useState({ x: 0, y: 0 });
  const canvasRef = useRef(null);
  const [minZoom, setMinZoom] = useState(0.1); // Define the minZoom state
  const {loading}=useSelector((state)=>state.parking)

  useEffect(() => {
    if (canvasRef.current) {
      const canvas = panzoom(canvasRef.current, {
        maxZoom: 3,
        minZoom: minZoom,
        autocenter: true,
        disableDoubleClickZoom: true,
        zoomDoubleClickSpeed: 1,
        
      });
      // Check if panScale has not been set and parkingData has loaded
      if (panScale === -1 && parkingData && parkingData.length > 0) {
        const maxParkingSlots = Math.max(...parkingData.map((item) => item.max_parking_slots));
        const initialPanScale = 1 / (maxParkingSlots * 0.1);
        setPanScale(initialPanScale - 0.1); // Adjust the initial panScale
        canvas.zoomAbs(panPosition.x, panPosition.y, initialPanScale - 0.1); // Set the initial zoom
      } else {
        canvas.zoomAbs(panPosition.x, panPosition.y, panScale);
      }
     
      return () => {
        canvas.dispose();
      };
    }
  }, [parkingData, panScale, panPosition, minZoom]);

  const handleZoomIn = (e) => {
    e.preventDefault();
    setPanScale(panScale + 0.5);
  };

  const handleZoomOut = (e) => {
    e.preventDefault();
    setPanScale(panScale - 0.5);
  };

  return (
    <div className="parking-map-wrapper">
      {/* <div className="parking-buttons">
        <Button aria-label="zoomin" color="primary" size="small" onClick={handleZoomIn}>
          <AddCircleOutlineIcon fontSize="large" />
        </Button>
        <Button aria-label="zoomout" color="primary" size="small" onClick={handleZoomOut}>
          <RemoveCircleOutlineIcon fontSize="large" />
        </Button>
      </div> */}
      {/* {parkingData?.length > 0 ? ( */}
      
        <div
          className="parking-map-wrapper-inner"
          ref={canvasRef}
          style={{
            width: '100%',
            height: '100%',
          }}
        >
        {
            parkingData?.map((item, index) => {
              const parkingSlots = item.parking_slots;

              return (
                <div key={index}>
                  <PanZoomCol
                    item={item}
                    index={index}
                    open={open}
                    parkingSlots={parkingSlots}
                    data={data}
                    setdata={setdata}
                  />
                </div>
              );
            })}
        </div>
      {/* // ) : (
      //   <div
      //     style={{
      //       display: 'flex',
      //       justifyContent: 'center',
      //       alignItems: 'center',
      //       height: '100%',
      //     }}
      //   >
      //     <Loader />
      //   </div>
      // )} */}
    </div>
  );
};

export default React.memo(Panzoomcls);
